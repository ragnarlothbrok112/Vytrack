package com.translantic.pages;

public class DashboardPage extends BasePage {
}
