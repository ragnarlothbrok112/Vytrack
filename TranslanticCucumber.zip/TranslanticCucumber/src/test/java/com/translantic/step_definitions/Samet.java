package com.translantic.step_definitions;

import com.translantic.pages.LoginPage;
import com.translantic.utilities.ConfigurationReader;
import com.translantic.utilities.Driver;
import io.cucumber.java.en.Given;

public class Samet {

    @Given("the user logs in as {string}")
    public void the_user_logs_in_as(String string) {
//        System.out.println(string); //driver_username
        //System.out.println(ConfigurationReader.get(string));
        String url = ConfigurationReader.get("url");
        Driver.get().get(url);
        LoginPage loginPage =new LoginPage();
        loginPage.loginSam(string);

    }
}
